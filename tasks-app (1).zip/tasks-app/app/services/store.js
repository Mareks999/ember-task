import { useLegacyStore } from '@warp-drive/legacy';
import { JSONAPICache } from '@warp-drive/json-api';

const Store = useLegacyStore({
  linksMode: false,
  cache: JSONAPICache,
  handlers: [],
  schemas: [],
});

export default Store;
