import Service from '@ember/service';
import { action } from '@ember/object';
import { tracked } from '@glimmer/tracking';

const STORAGE_KEY = 'uzdevumu-saraksts';

export default class TaskStoreService extends Service {
  @tracked tasks = [];

  constructor() {
    super(...arguments);
    this.tasks = this.load();
  }

  load() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      return Array.isArray(saved) ? saved : [];
    } catch {
      return [];
    }
  }

  persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.tasks));
  }

  @action
  add(title) {
    this.tasks = [...this.tasks, { id: Date.now(), title, done: false }];
    this.persist();
  }

  @action
  toggle(id) {
    this.tasks = this.tasks.map((task) =>
      task.id === id ? { ...task, done: !task.done } : task,
    );
    this.persist();
  }

  @action
  remove(id) {
    this.tasks = this.tasks.filter((task) => task.id !== id);
    this.persist();
  }

  @action
  clearDone() {
    this.tasks = this.tasks.filter((task) => !task.done);
    this.persist();
  }
}
