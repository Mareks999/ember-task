import { pageTitle } from 'ember-page-title';
import { LinkTo } from '@ember/routing';

<template>
  {{pageTitle "Uzdevumu saraksts"}}

  <header class="site-header">
    <h1>Uzdevumu saraksts</h1>
    <nav>
      <LinkTo @route="index">Uzdevumi</LinkTo>
    </nav>
  </header>

  <main class="page">
    {{outlet}}
  </main>
</template>
