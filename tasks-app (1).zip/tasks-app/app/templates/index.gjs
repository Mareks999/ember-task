import TaskList from 'tasks-app/components/task-list';

<template><TaskList /></template>
