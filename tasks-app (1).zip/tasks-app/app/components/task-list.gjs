import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { service } from '@ember/service';
import { action } from '@ember/object';
import { on } from '@ember/modifier';
import { fn } from '@ember/helper';

export default class TaskList extends Component {
  @service taskStore;

  @tracked newTitle = '';
  @tracked error = '';
  @tracked filter = 'all';

  get visibleTasks() {
    const tasks = this.taskStore.tasks;
    if (this.filter === 'active') return tasks.filter((task) => !task.done);
    if (this.filter === 'done') return tasks.filter((task) => task.done);
    return tasks;
  }

  get doneCount() {
    return this.taskStore.tasks.filter((task) => task.done).length;
  }

  get filterButtons() {
    return [
      { key: 'all', label: 'Visi' },
      { key: 'active', label: 'Aktīvie' },
      { key: 'done', label: 'Izpildītie' },
    ].map((item) => ({ ...item, isActive: item.key === this.filter }));
  }

  @action
  updateTitle(event) {
    this.newTitle = event.target.value;
  }

  @action
  addTask(event) {
    event.preventDefault();
    const title = this.newTitle.trim();

    if (title.length < 3) {
      this.error = 'Uzdevuma nosaukumam jābūt vismaz 3 simbolus garam.';
      return;
    }

    this.taskStore.add(title);
    this.newTitle = '';
    this.error = '';
  }

  @action
  setFilter(key) {
    this.filter = key;
  }

  <template>
    <form class="task-form" {{on "submit" this.addTask}}>
      <label for="new-task">Jauns uzdevums</label>
      <div class="form-row">
        <input
          id="new-task"
          type="text"
          placeholder="Ko jāizdara?"
          value={{this.newTitle}}
          {{on "input" this.updateTitle}}
        />
        <button type="submit">Pievienot</button>
      </div>
      {{#if this.error}}
        <p class="error" role="alert">{{this.error}}</p>
      {{/if}}
    </form>

    <div class="toolbar">
      <p class="counter">
        Izpildīti:
        {{this.doneCount}}
        no
        {{this.taskStore.tasks.length}}
      </p>
      <div class="filters">
        {{#each this.filterButtons as |item|}}
          <button
            type="button"
            class={{if item.isActive "active"}}
            {{on "click" (fn this.setFilter item.key)}}
          >{{item.label}}</button>
        {{/each}}
      </div>
    </div>

    <ul class="task-list">
      {{#each this.visibleTasks as |task|}}
        <li class={{if task.done "done"}}>
          <label>
            <input
              type="checkbox"
              checked={{task.done}}
              {{on "change" (fn this.taskStore.toggle task.id)}}
            />
            <span>{{task.title}}</span>
          </label>
          <button
            type="button"
            class="remove"
            aria-label="Dzēst uzdevumu"
            {{on "click" (fn this.taskStore.remove task.id)}}
          >×</button>
        </li>
      {{else}}
        <li class="empty">Šeit vēl nav neviena uzdevuma.</li>
      {{/each}}
    </ul>

    {{#if this.doneCount}}
      <button
        type="button"
        class="clear"
        {{on "click" this.taskStore.clearDone}}
      >
        Dzēst izpildītos
      </button>
    {{/if}}
  </template>
}
