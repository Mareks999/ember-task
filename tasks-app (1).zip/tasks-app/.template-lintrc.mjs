export default {
  extends: 'recommended',
};
